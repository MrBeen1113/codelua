init("com.tencent.xin",0);
  mSleep(1500);
  luaExitIfCall(true)
--  ///////////////点击函数
	function touchDU(x,y)  
        wLog("WX@","touchDU点击:"..(x)..","..(y)..")")
        touchDown(1,x,y)
        mSleep(30)
        touchUp(1,x,y)
     end
--//////////////////////滑动函数
function MouveDU(tx,ty,cd,bc)
	
	
	     touchDown(1, tx, ty); --在 (150, 550) 按下
        for i = 0, cd, bc do   --使用for循环从起始点连续横向移动到终止点
        touchMove(1, tx , ty - i );    
        
        mSleep(40);        --延迟
        end
         touchUp(1, tx, ty - cd)
        mSleep(300)
end
	--//发送复制
function fuzhi()
	 mSleep(1200);
	
	 touchDU(200,590);--点击输入框
	
	 mSleep(500);

	 string = readPasteboard();  --读出剪贴板内容
	 
     mSleep(500); --延迟 0.5 秒
	
     inputText(string);          --写出字符串
	  
	 mSleep(1000);  
	
	 touchDU(1490,96);--点击完成
	
	 mSleep(1000);
	
	 touchDU(900,1100);--点击发送
	
	 mSleep(1000);
	
end
--
initLog("WX@",0); --记录日志

		mSleep(1000);
		MouveDU(200,207,100,10);
		
		for i=0 ,10000,1 do
			
			x,y = findMultiColorInRegionFuzzy( 0xfefefe, "21|-5|0xfefefe,30|19|0xfefefe,11|42|0xfefefe,41|42|0xfefefe,57|38|0xfefefe,70|23|0xfefefe,39|55|0xfefefe", 100, 0, 1500, 200, 2047)
			 if x ~= -1 and y ~= -1 then --如果在指定区域找到某图片符合条件
		      wLog("WX@","添加图片位置("..(x)..","..(y)..")")
			 --  
		      for j=0,13,1 do
				  
		       mSleep(100);
			   
			  local  m = 0 ;
			     m = 180 + j*130;
			     mSleep(100);
			
		        touchDU(180,m);
			    mSleep(500);
		        fuzhi();
			    mSleep(1000);
			 end
			  lua_exit(); 
			else
			  mSleep(500);
			
		      touchDU(180,180);
			  mSleep(1000);
			
			 touchDU(1490,96); --点击右上脚小人
			 mSleep(2000); 
			--//判断思享小管家是否为群主
			 x,y = findMultiColorInRegionFuzzy( 0x1870ee, "-3|26|0x186bec,-2|47|0x1a72f6,0|74|0x1e76f6,27|54|0xf1feff,70|38|0xe9f6fe,84|16|0x1f77fd,88|-1|0x2077fc", 90, 20, 175, 150, 310);
			 if x ~= -1 and y ~= -1 then 
			     --思享小管家为群主继续运行程序
				 mSleep(1000);
			
			     MouveDU(200,2007,1500,100);
			
			     mSleep(1000);
			
			     touchDU(1420,700); --点击未设置
			
			     mSleep(1000);
				 --判断是否已设置了群公告
				 x,y = findMultiColorInRegionFuzzy( 0x1d72f3, "0|21|0x176be8,0|41|0x176feb,22|8|0xfefcfb,51|17|0x2675fe,40|40|0xe5f6ff", 90, 29, 163, 102, 236)
				 if x ~= -1 and y ~= -1 then 
				     
					 mSleep(1000);
					 touchDU(1485,85); --点击编辑
					 mSleep(1000);
	                 for i=0 ,200,1 do
					     mSleep(50);
						 touchDU(1460,1590); --点击删除按键
				     end
				
				     mSleep(1000);		 
		             fuzhi();--调用复制函数	
					
                     mSleep(2000);			
			         touchDU(70,77); --点击返回			
			         mSleep(1000);			
			         touchDU(70,77); --点击返回
		             mSleep(1000); 
				 else
					 mSleep(1000);		 
		             fuzhi();--调用复制函数			
			  		 mSleep(2000);			
			         touchDU(70,77); --点击返回			
			         mSleep(1000);			
			         touchDU(70,77); --点击返回
		             mSleep(1000); 			
				 end
				
		     else
			     mSleep(1000);			
			     touchDU(70,77); --点击返回			
			     mSleep(1000);			
			     touchDU(70,77); --点击返回		 
		         mSleep(1000);	
			 end

		      MouveDU(200,257,150,10); 
		   end
	     end 
        mSleep(1000);
        lua_exit();          --退出脚本
  
	closeLog("WX@"); 